# This is my program that simulates the game of blackjack.
# Both the user and the computer are dealt two cards and are repeatingly asked if they want to hit or stay. The computer's cards are hidden from the user until they decide to stay.
import random
from art import logo
from replit import clear

#The cards array simulates the deck the player draws from to add to their hand.
cards = [11,2,3,4,5,6,7,8,9,10,10,10,10]
player_1 = []
player_2 = []
add_cards_1 = 0
add_cards_2 = 0
def user(player_1):
  return sum(player_1)
  check_for_blackjack = sum(player_1)
  if check_for_blackjack == 21:
    return 0
  if check_for_blackjack > 21:
    player_1.remove(11)
    player_1.append(1)
    return sum(player_1)
def computer(player_2):
  return sum(player_2)
def ace(card):
  if card > 21:
    return card - 10
    
should_continue = True
play_Game = input("Do you want to play a game of BlackJack? Type 'y' or 'n' ")
if play_Game == 'y':
   player_1.append(random.choice(cards))
   player_1.append(random.choice(cards))
   user_hand = user(player_1)
   player_2.append(random.choice(cards))
   player_2.append(random.choice(cards))
# The while loop is used to keep the game going until the user decides to stop.
# The if statement is used to check if the user has a blackjack and if they do, the game ends.
# The game can also end by the computer having a blackjack, the user having a score higher than 21.
   while should_continue is True:
      user_hand = user(player_1)
      comp_hand = computer(player_2)
      print(player_1)
      if user_hand == 21:
        print("You have won")
        should_continue = False
      elif computer == 21 or user_hand == 0 or user_hand > 21:
        print("You have lost")
        should_continue = False
# If none of the above conditions have been met, the player will be asked if they want to hit or stay.
# If the user decides to hit, a new card will be added to their hand with their total score and hand being shown.
      another = input(f"Do you want to draw another card? "
                      f"Your hand value is {user_hand}.'y' or 'n' ")
      if another == "y":
         player_1.append(random.choice(cards))
         user_hand = user(player_1)
         print(player_1)
         print(f"Your hand value is {user_hand}")
      elif another == "n":
         player_2.append(random.choice(cards))
         comp_hand = computer(player_2)
         print("computer draws another card")
         if comp_hand > 21:
           print("You win")
           should_continue = False
         if comp_hand > user_hand and comp_hand > 21:
             print("you lose")
             print(f"computer has a hand value of {comp_hand} and you " 
                   f" have a value of {user_hand}")
             should_continue = False
         elif comp_hand < user_hand:
             print("You win!")
             print(f"computer has a hand value of {comp_hand} and you "
                   f"have a value of {user_hand}")
             should_continue = False
         else:
             print("You draw")
             should_continue = False
             print(f"You and the computer both have a hand value of {user_hand}")
else:
  clear()